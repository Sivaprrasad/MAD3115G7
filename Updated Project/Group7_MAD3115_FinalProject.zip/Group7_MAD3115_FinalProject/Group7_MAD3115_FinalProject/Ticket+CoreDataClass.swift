//
//  Ticket+CoreDataClass.swift
//  Group7_MAD3115_FinalProject
//
//  Created by  Z Angrazy Jatt on 2018-11-17.
//  Copyright © 2018 Z Angrazy Jatt. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Ticket)
public class Ticket: NSManagedObject {

}
